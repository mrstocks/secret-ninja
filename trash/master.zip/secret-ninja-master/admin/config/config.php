<?php
$host	= $_SERVER['HTTP_HOST'];
$uri	= rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$salt	= "hfeirfhsdkjf34543543EZfRXC4Z";
$path	= "/opt/secret-ninja/admin/"
?>	
