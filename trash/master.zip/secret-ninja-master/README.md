<h1>Secret ninja</h1>

<h4>General information</h4>
Url : http://elevage-fees-de-celestia.fr:3333/<br />
Template : http://62.210.239.213:3333/public/Flat-UI-master/<br />
Mysql Admin: http://elevage-fees-de-celestia.fr:3333/phpmyadmin/<br />
Datamapping ORM :http://www.phpactiverecord.org/ We use the developper version not the stable one
Admin:
  * username: mrstocks
  * password: oliver


<pre>
 - [ ] To do.
 - [X] done.
</pre>

<h4>TODO list</h4>
  * Gallery Section
     * -[ ] Add a column for links on the gallery sections table
  * Core application
    * Routes
      * - [ ] Parse the url and remove slashes
    *  Add helpers
      * - [X] Error must redirect and log the errors  
      * - [X] Image helper
      * - [X] Menu helper
      * - [X] Back link
  * Bienvenu
    * - [ ] Add a relation mysql -> carrousel
  * News module
    * - [ ] When uploading a new image in the backend we must make a thumb for 
    * - [ ] The image has to centered and "fixed"
  * Dogs controller
    * - [X] Rename the testright to textright code also
  * General UI
    * - [ ] All the design is pushed right there i don't know why maybe a div missing
    * - [ ] Video isn't the right size
    * - [ ] link on the footer don't work, need to make a contact section
    * - [ ] General UFT8 problem all the é don't work
    * - [ ] The footer is not responsive
  * Puppies section
  * Contact section
    * - [*] Add Gmail map to come and visit me
    * - [X] Add Email form using mail email service
    * - [X] Add address and telephone numer
    * - [*] Link to section with CV etc
    * - [*] UI Faulty. The footer first cases pop up behind the address
    * - [X]  Translate from English to French
    * - [X] Add Gmail map to come and visit me
    * - [X] add Latitude and Longitude of current location
    * - [X] Obtain maps API key
    * - [X] Add Email form using mail email service
    * - [X] Fill in username and password for gmail account to be used
    * - [X] Add address and telephone number
    * - [X] Link to section with CV etc
